# AGENTS — Deskverse

Estas instruções valem para todo o repositório.

## Produto

O Deskverse é uma aplicação web de workspace visual:

- Next 16, React, Tailwind CSS, shadcn/ui, React Flow quando relações entre itens precisarem ser exibidas e Motion para transições.
- O código-fonte do app Next.js fica em `src`, com `src/app` para App Router e `src/components` para componentes; `package.json`, `next.config.ts`, `tsconfig.json`, `public` e demais configurações ficam na raiz do projeto.
- Antes de alterar código ou configuração do Next.js, consulte a documentação local correspondente em `node_modules/next/dist/docs/`.
- Workspace central em canvas DOM de tela inteira, com uma grade espacial de tiles/logos dos agentes. Não tratar essa superfície como Kanban, lista de tarefas ou quadro com colunas.
- Cards representam pessoas, agentes, projetos, planos, tarefas, arquivos, entregas e atividade.
- Painéis contextuais mostram conversa, estado, decisão pendente e histórico.
- A tela dedicada de gerenciamento de projetos, separada do canvas e dos painéis contextuais, é somente leitura para o usuário: exibe projetos, objetivos, planos, tarefas, dependências, responsáveis, prazos, saúde e histórico sem oferecer operações de criação, edição ou exclusão.
- Alterações de planejamento são feitas exclusivamente por tools autorizadas dos agentes Gestor de Projetos/Gerente e Social Media, com origem, estado anterior, novo estado e próximo passo rastreáveis.
- Antes da criação dos agentes do MVP, a Fase 08 deve entregar a tela de arquivos dos projetos: os agentes enviam seus trabalhos para o UploadThing por tools e o usuário apenas consulta os arquivos e metadados.
- A tela de arquivos usa Data Table do shadcn/ui com paginação e busca em desktop; em viewport mobile, a mesma informação vira uma lista de cards sem exigir rolagem horizontal.
- O usuário deve acompanhar o trabalho sem perder posição, foco ou contexto.
- Toda interface ou funcionalidade deve ser pensada desde o início para usabilidade mobile: layout responsivo, hierarquia legível, ações acessíveis por toque e teclado, estados completos e nenhum fluxo essencial dependente de largura de desktop.
- Crie componentes reutilizáveis sempre que a repetição, a consistência visual ou a composição da interface tornar isso oportuno; mantenha APIs pequenas, acessíveis e próximas do domínio que realmente compartilham.
- Evite arquivos muito longos e vários componentes, funções ou responsabilidades sem relação no mesmo arquivo. Separe módulos por domínio e responsabilidade quando o tamanho, a reutilização ou a testabilidade justificar.
- Prefira funções pequenas e reutilizáveis, extraia lógica compartilhada em módulos próprios e reutilize funções existentes antes de criar duplicações locais.
- Existe um chat global com todos os agentes listados e disponível para todos os agentes, além de chats privados abertos ao selecionar o card de um agente. O chat global pode alimentar a memória compartilhada; o privado respeita o escopo e a permissão da conversa.
- Notificações em tempo real são o canal principal para pedidos de permissão, incluindo solicitações de alteração da própria configuração do agente, e também comunicam conclusão, falha, espera e mudanças relevantes.
- Cada card deve refletir visualmente a atividade, a permissão pendente, a espera, a conclusão ou a falha correspondente à notificação e à execução real.

## Stack obrigatória

- Next 16
- Tailwind CSS
- shadcn/ui
- Better Auth
- Prisma ORM
- Zod
- React Hook Form
- Lucide Icons
- date-fns
- Motion
- PostgreSQL
- pgvector como extensão do PostgreSQL para toda memória dos agentes
- Abacate Pay para billing e pagamentos
- UploadThing para armazenamento dos arquivos produzidos pelos agentes

Use essa stack como padrão do produto. Uma dependência adicional precisa de justificativa no escopo da sprint e não deve duplicar uma capacidade já coberta por esses componentes.
Abacate Pay é o provedor oficial de billing: checkout, assinaturas, retorno, webhooks e reconciliação devem seguir esse provedor.

## Arquitetura operacional de agentes

- `LeaderAgent` é persistente e mantém objetivo, contexto organizacional, decisões e delegação.
- `SpecialistAgent` é lógico, reutilizável e compartilhado entre líderes. A delegação usa especialidade/capacidade; não usa ID fixo de agente ou worker.
- `WorkerAgent` é efêmero e representa uma execução LLM, CPU, GPU, navegador, render ou mídia. Não deve virar identidade persistente na interface.
- O contrato do produto é `Harness = AgentPolicy + TaskPolicy + ModelAdapter`.
- `AgentRuntime` abstrai Eve. `InferenceGateway` abstrai o Vercel AI Gateway. O Deskverse decide inteligência e política; runtime executa e gateway transporta.
- A métrica principal é `cost_per_successful_task`: custo total atribuível às tentativas dividido pelo número de tarefas concluídas corretamente.
- Todo trace registra senioridade e raciocínio solicitados, aplicados e eventualmente rebaixados pelo adapter. OpenAI e Anthropic nunca usam `max`; outras famílias dependem do `ModelCapabilityProfile` e do benchmark.
- Filas são separadas em líder, especialidade compartilhada e classe física (`LLM`, `CPU`, `GPU`, `BROWSER`, `RENDER`), com prioridade, FIFO por faixa, aging, justiça, limite de concorrência, backpressure, lease/heartbeat, retry técnico idempotente, deduplicação quando aplicável, dead-letter e cancelamento em cascata.
- `WAITING_USER` e `WAITING_APPROVAL` persistem checkpoint e liberam a execução física. Falha técnica e falha semântica têm tratamentos distintos.

## Banco de dados e migrations

- PostgreSQL é o banco de dados da aplicação e Prisma ORM é a camada de acesso e evolução do modelo.
- Toda alteração persistente — incluindo modelos, campos, relações, enums, índices ou restrições — deve gerar uma migration Prisma versionada.
- A migration e a alteração do schema devem entrar no mesmo commit da funcionalidade.
- Não use alteração manual no banco ou prisma db push para substituir uma migration versionada.
- Valide a migration em banco local limpo, confirme prisma migrate status e registre incompatibilidades ou etapas de dados na sprint.
- Alterações de dados existentes devem ser seguras, repetíveis e acompanhadas de estratégia explícita de backfill quando necessário.
- Zod valida entradas e dados nas bordas da aplicação; não substitui a migration nem a integridade do PostgreSQL.

## Fonte de verdade

Antes de escolher ou iniciar uma sprint, leia:

1. docs/sprints/SPRINT_STATUS.md
2. docs/sprints/00-meta/SPRINT_MANIFEST.json
3. docs/sprints/00-meta/SUPERVISOR_PROMPT.md
4. a README e o arquivo da sprint escolhida

O manifesto define ordem, dependências, ambiente e prioridade. Sprints ativas ficam em docs/sprints/<fase>/. Sprints concluídas ficam em docs/sprints/completed/<fase>/.

A próxima prioridade é SPRINT-06-01 — Estrutura final da aplicação e limites de responsabilidade. A fundação 06-01 a 06-07 precede a Sprint 05-01 por override explícito do manifesto.

## Ordem de criação dos agentes do MVP

A ordem abaixo é obrigatória e deve permanecer visível no roadmap e nas implementações:

1. SPRINT-10-01 — Mídias Sociais
2. SPRINT-10-02 — Redator
3. SPRINT-10-03 — Designer
4. SPRINT-10-04 — fluxo Mídias Sociais → Redator → Designer
5. SPRINT-10-05 — presença dos três no escritório
6. SPRINT-10-06 — primeiro fluxo pós-onboarding
7. SPRINT-10-07 — experiência local integrada

O Gate A0 é: plano de mídias sociais → texto → design quando disponível → aprovação humana → entrega. Sem capacidade ou entitlement do Designer, o fluxo conclui pelo caminho Mídias Sociais → Redator, com aviso explícito.

## Comportamento dos agentes

- Usuários leigos recebem perguntas curtas de refinamento quando a instrução estiver ambígua.
- A camada de refinamento confirma um brief antes de executar ou delegar ao líder ou ao agente direto.
- A instrução original, perguntas, respostas e decisões permanecem rastreáveis.
- Agentes podem colaborar para melhorar o pedido antes de produzir o resultado.
- Aprovação, espera, cancelamento, takeover e escalonamento são estados visíveis.
- Takeover humano interrompe ações protegidas e novos envios.
- Fatos ausentes ou conflitantes geram pergunta ou escalonamento; não invente preço, política, prazo ou promessa.
- Ferramentas são autorizadas por capacidade, permissão, conexão, autonomia e contexto do workspace.
- Toda memória dos agentes — compartilhada, individual, de projeto, preferência, decisão, tarefa ou conversa elegível — usa PostgreSQL com pgvector; não crie um segundo armazenamento de memória.
- Preferências alteradas, tarefas concluídas, decisões confirmadas e outros fatos duráveis podem ser salvos em memória com origem, escopo, data e confiança para serem recuperados depois.
- Um agente pode solicitar, por tool, alteração da própria configuração quando isso for necessário, mas a mudança só ocorre após a permissão adequada e deve gerar notificação em tempo real e feedback visível no card.
- Todos os agentes devem usar o sistema de notificações em tempo real para pedidos de permissão, espera, falha, conclusão e eventos que exigem atenção humana ou de outro agente.
- WhatsApp e Instagram usam um núcleo de mensagens neutro ao provedor; contas são autenticadas por workspace e atribuídas com permissões por especialidade. A inbox unificada cobre mensagens, DMs e comentários. Takeover humano exige sinal confiável de coexistência e a escalação preserva agente, superior, humano, motivo e auditoria.

## Capacidades específicas

- O agente de imagem tem dois níveis: Apenas criação de imagens e Criação e edição.
- No segundo nível, a arte social media usa um LLM orquestrador, Qwen-Image para composição/layout, FLUX.2 Klein para partes e variações e a Image Editing Tool própria para edição e recomposição pontual. O modelo orquestrador não é confundido com o gerador visual.
- A tool de imagem trabalha com composição JSON, layers, transformações, alpha, blend modes, máscaras, ajustes, comandos undo/redo, API para agentes e exportação PNG.
- O agente de motion design usa Remotion e uma tool/MCP interna baseada no clone do Figma para criar vetores. Essa tool é interna aos agentes e não ganha uma tela pública sem decisão explícita.
- O agente de edição de vídeo possui níveis Básico, Intermediário e Avançado. As capacidades de cada nível são definidas na sprint de implementação.
- Social Media, Design e Edição de Vídeo oferecem estilos diferentes por select na interface de criação/configuração. As famílias de estilo são definidas durante a implementação de cada agente.
- Convites e entrada de colaboradores pertencem à SPRINT-16-05 e não fazem parte do primeiro uso.

## Canvas, movimento e imersão

- Use componentes DOM e mantenha as regras próximas da feature, com tipos, estado e fixtures locais.
- O canvas deve ocupar toda a viewport. Não reserve uma coluna permanente para menus, filtros, atividade ou contexto; essas superfícies devem abrir em sheets/drawers sobre o canvas.
- Controles simples do canvas, como zoom, restaurar visão, encaixar na tela e iniciar uma demonstração, devem ser botões somente com ícone, com `aria-label` e tooltip, distribuídos harmonicamente em posição absoluta sobre o canvas.
- A composição principal é uma grade espacial única de logos/tiles de agentes, sem lanes, colunas, agrupamentos de trabalho ou semântica de Kanban.
- O número de colunas do wall deve considerar a quantidade de agentes visíveis: priorize uma geometria próxima de quadrado, usando a raiz quadrada arredondada para cima como referência, e aceite uma última linha parcial quando a quantidade não formar um quadrado perfeito; adapte o limite de colunas à largura mobile.
- No desktop, mantenha o wall compacto e centralizado, limitando cada tile a aproximadamente 180px; no mobile, permita que os tiles ocupem a largura disponível sem perder a proporção 1:1.
- Os tiles de agentes devem ser minimalistas e manter proporção 1:1 em qualquer viewport. Não crie molduras, badges ou bordas internas envolvendo a logo; mantenha apenas a borda externa necessária para foco e estado de atividade.
- Ícones/logos devem usar traços finos. Tags de estado ficam no canto superior direito do tile, sem competir com a logo ou com o nome do agente.
- O ícone/logo deve ser grande, centralizado e ter opacidade baixa, aproximadamente 30%; nome e cargo ficam centralizados sobre a logo. O rodapé exibe uma frase de no máximo três palavras preenchida pelo agente para resumir a ação atual.
- O status visual do tile é somente uma bolinha colorida no canto superior direito, e a borda externa acompanha a mesma cor: roxo para trabalhando, vermelho para erro/ajuda, verde para disponível e amarelo para aguardando resposta.
- A logo de cada agente começa neutra, cinza e dessaturada. Ela só ganha a cor própria, halo ou pulso quando o agente estiver trabalhando ou participando de uma comunicação; espera e disponibilidade permanecem visualmente discretas.
- Quando um agente se comunicar com outro, mova o card emissor para um slot ao lado do destinatário.
- Enquanto a comunicação estiver ativa, conecte os dois tiles com uma linha animada e discreta, desenhada entre as bordas externas dos cards e sincronizada com o reflow.
- O usuário pode reposicionar qualquer tile com React DnD: no desktop, arrasta com clique sustentado usando o backend HTML5; no mobile, inicia o arraste após segurar o tile por um segundo usando o backend de toque. Enquanto arrasta, os demais tiles fazem reflow fluido e rápido, inspirado no rearranjo de ícones do iOS.
- A ordem manual é uma preferência por usuário e workspace. A atualização visual não pode esperar a rede; persista a nova ordem de forma assíncrona em PostgreSQL por meio de Prisma, com migration obrigatória, retry/feedback não bloqueante e sem perder a ordem local em caso de falha.
- Grupos de agentes com comunicação interna mediada por um líder pertencem a uma funcionalidade futura. Não antecipe containers, hierarquias ou regras de execução de grupo no canvas atual; quando a sprint futura for iniciada, cada grupo deve coexistir no mesmo canvas e preservar os princípios de reflow, acessibilidade e comunicação visual.
- Reorganize os demais cards com reflow animado e preserve a continuidade espacial.
- Mudanças no grid devem nascer de atividade explícita, manter seleção e foco e mostrar o estado da comunicação.
- Animações devem ser fluidas, suaves e rápidas, sem espera artificial ou sensação de lentidão.
- Hover, foco, mudança de status e entrada/saída de atividade devem ter transições curtas e suaves; o hover do tile deve elevar e ampliar sutilmente o card com Motion, enquanto fundo, borda e logo fazem transição. Quando o status mudar, anime discretamente o ponto, a borda e o halo para comunicar a mudança sem distrair.
- Toda animação relevante deve considerar prefers-reduced-motion.
- Não esconda erro, espera humana ou indisponibilidade atrás de animação.

## Execução de sprints

1. Confirme todas as dependências e gates antes de iniciar.
2. Entregue uma sprint por agente ou worktree e não misture fases sem decisão de integração.
3. Implemente o fluxo principal e os estados loading, empty, error, success e WAITING_USER.
4. Registre dependências externas e decisões pendentes em integration-requirements.
5. Não conecte módulos silenciosamente nem aumente o escopo da sprint.
6. Preserve os arquivos e alterações de outras tarefas.
7. Um agente subordinado não cria ou delega trabalho para outro agente.

## Qualidade e conclusão

Uma sprint só pode ser marcada como COMPLETE ou COMPLETE_WITH_INTEGRATION_REQUIREMENTS depois de:

- executar testes, lint, typecheck, build e validações específicas;
- demonstrar a interface no navegador quando houver mudança visual;
- registrar evidências, artefatos, riscos e integrações pendentes;
- verificar acessibilidade, teclado, viewport estreita e redução de movimento quando aplicável.

BLOCKED_BY_FOUNDATION_GATE e FAILED_ACCEPTANCE permanecem visíveis até resolução.

## Git

- Verifique git status antes e depois do trabalho.
- Não inclua arquivos alterados por outras tarefas, artefatos temporários ou dependências geradas.
- Use mensagem curta e descritiva.
- Ao concluir, faça commit das alterações relacionadas e git push para o remoto da branch atual.
- Confirme que a branch local está sincronizada com o remoto.
- Se commit ou push falhar, informe o erro exato e não declare a tarefa concluída.

<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
