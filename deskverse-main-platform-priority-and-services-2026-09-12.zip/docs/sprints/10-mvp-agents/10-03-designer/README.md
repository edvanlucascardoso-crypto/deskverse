# Grupo 10-03 — Designer

Sprint funcional canônica: [SPRINT-10-03](../SPRINT-10-03.md). As sprints 11-01/11-02 são seu gate técnico antecipado.

## Serviço associado

- [MCP de mídia](services/SPRINT-10-03-SVC-01-mcp-media.md): serviço Railway privado para composição, edição e referências de assets. A criação visual continua orientada pelo orquestrador e pela arquitetura Qwen-Image + FLUX.2 Klein + Image Editing Tool.

