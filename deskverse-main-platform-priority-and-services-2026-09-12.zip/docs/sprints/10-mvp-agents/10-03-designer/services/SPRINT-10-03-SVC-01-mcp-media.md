# SPRINT-10-03-SVC-01 — MCP de mídia no Railway

**Depende de:** 08-02, 09-04 e gates 11-01/11-02.  
**Não bloqueia:** Mídias Sociais → Redator sem Designer.

## Objetivo

Disponibilizar uma tool externa privada para o Designer criar composição, solicitar edição pontual, versionar resultado e devolver referências de assets. O serviço não decide a tarefa nem escolhe o modelo.

## Implementação

- Serviço Railway `deskverse-mcp-media`, sem endpoint público de usuário.
- Autorização por workspace, schema estruturado, idempotency key, timeout e auditoria.
- Entrada/saída pesada por R2/S3 com URLs assinadas; nunca transportar binário no MCP.
- Jobs CPU/GPU entram nas filas físicas; preview/aprovação libera worker enquanto aguarda humano.
- Persistir composição master, versão, inputs/outputs, custo, erro e lineage no Neon.

## Aceite

- Uma edição pontual preserva a composição aprovada e é reprodutível.
- Falha de worker não perde job ou asset; retry técnico é idempotente.
- O LLM não recebe segredo de storage/GPU e o usuário não acessa o MCP diretamente.

