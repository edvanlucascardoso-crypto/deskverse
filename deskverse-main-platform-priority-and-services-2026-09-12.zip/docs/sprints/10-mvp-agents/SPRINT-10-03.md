# SPRINT-10-03 — Designer e agente de imagem

**Fase:** 10 — Agentes do MVP  
**Status inicial:** PLANNED  
**Dependências:** SPRINT-09-08, SPRINT-08-02 e SPRINT-11-02  
**Superfície principal:** orquestração visual

`SPRINT-11-01`/`SPRINT-11-02` são um gate técnico antecipado: devem concluir antes desta sprint, embora a ferramenta permaneça catalogada na Fase 11. O restante da Fase 11 não é puxado para antes da Fase 10.

## Objetivo

Entregar um Designer que atua como **orquestrador visual**, preservando composição e usando geração por partes apenas quando isso melhora qualidade/custo/controle.

## Inference profile

- LLM orquestrador padrão: **Qwen 3.5 Plus**.
- Escalation: **Kimi K3** para planejamento visual/engenharia long-horizon complexa.
- Modelos de imagem: **Qwen-Image** para layout/tipografia/composição e **FLUX.2 Klein** para fotografia, produto, fundo, objetos/partes e variações.
- A edição pontual é feita pela **Image Editing Tool própria**, não pelo LLM.

## Fluxos

### Geração simples
Gerar no modelo visual mais adequado e corrigir localmente se necessário.

### Edição localizada
Preservar a imagem original; usar a tool. Se precisar de novo asset, gerar somente a parte necessária.

### Composição complexa
1. gerar `master composition` completa;
2. pedir aprovação estrutural;
3. somente depois gerar/regerar partes isoladas na qualidade necessária;
4. recompor **na mesma posição, escala, proporção e hierarquia** da composição aprovada;
5. usar a tool para ajustes locais, evitando regenerar tudo.

O prompt é adaptado por modelo/subtarefa; nunca enviar o mesmo prompt bruto para todos.

## Preservação e versionamento

Guardar master, partes, masks, scene/composition JSON, versões e exports. BrandProfile, copy aprovada e referências são obrigatórios quando aplicáveis. Aprovação da composição complexa é um checkpoint do AgentRuntime.

## Critérios de aceite

- Um poster complexo gera master, pausa para aprovação e permite correção de uma parte sem reconstruir toda a arte.
- Elementos recompostos mantêm geometria da master aprovada.
- Cada geração/edição registra modelo, prompt adaptado, versão, custo e origem.
- Falta de BrandProfile/referência/permissão entra em WAITING_USER/APPROVAL.
- Resultado aparece na tela de arquivos após persistência confirmada.
