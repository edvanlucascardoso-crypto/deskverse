# Fase 11 — Integrações e Planejamento

Conectar ferramentas e canais externos ao fluxo de trabalho, mantendo autorização, aprovação, rastreabilidade e fallback claros.

## Ordem

1. SPRINT-11-01 — Criação visual assistida
2. SPRINT-11-02 — Geração e edição de imagens
3. SPRINT-11-03 — Canal Instagram
4. SPRINT-11-04 — Canal WhatsApp
5. SPRINT-11-05 — Conexões atribuições e inbox unificada
6. SPRINT-11-06 — Agenda de publicações
7. SPRINT-11-07 — Resumo diário e recomendações

A fase é executada na ordem indicada. Cada sprint apresenta o fluxo principal, estados recuperáveis, validações e integrações pendentes.

Exceção de dependência: as SPRINT-11-01 e SPRINT-11-02 são gates técnicos da SPRINT-10-03 e devem ser executadas antes do Designer do MVP. As sprints 11-03 a 11-07 permanecem posteriores à Fase 10.

## Limites

Regras e tipos ficam próximos da feature. Não se cria uma camada transversal prematura nem se muda a semântica do canvas para acomodar uma integração futura.
