# Fase 16 — Temas do Workspace

Oferecer variações visuais de workspace sem mudar a semântica dos cards, os estados do trabalho ou a acessibilidade.

## Ordem

1. SPRINT-16-01 — Tema visual Startup do workspace
2. SPRINT-16-02 — Tema visual Big Tech do workspace
3. SPRINT-16-03 — Troca de temas e capacidade do workspace
4. SPRINT-16-04 — Validação de performance e acessibilidade
5. SPRINT-16-05 — Convites e entrada de colaboradores

Convites são deliberadamente tardios: o usuário deve conseguir usar o workspace individualmente antes de adicionar qualquer colaborador.

Temas não podem remover a continuidade espacial do canvas. Toda mudança de tema e toda atividade devem preservar animações fluidas, suaves, rápidas e acessíveis.

A fase é executada na ordem indicada. Cada sprint apresenta o fluxo principal, estados recuperáveis, validações e integrações pendentes.

## Limites

Regras e tipos ficam próximos da feature. Não se cria uma camada transversal prematura nem se muda a semântica do canvas para acomodar uma integração futura.
