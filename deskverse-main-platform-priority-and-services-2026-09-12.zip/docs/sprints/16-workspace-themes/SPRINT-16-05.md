# SPRINT-16-05 — Convites e entrada de colaboradores

**Fase:** 16 — Temas do Workspace
**Status inicial:** PLANNED
**Dependências:** SPRINT-16-04
**Ordem:** uma das últimas entregas do roadmap
**Superfície principal:** administração do workspace

## Objetivo

Adicionar colaboração multiusuário somente depois que canvas, agentes, runtime, cobrança, segurança, release e temas estiverem estáveis. Convites não fazem parte da experiência inicial nem devem aparecer como requisito para o primeiro uso.

## Trabalho

- Criar convite, aceite, expiração, reenvio, remoção e saída do workspace.
- Exibir claramente papel, permissões, estado do convite e responsável pela ação.
- Proteger dados existentes contra convite malformado, token expirado e usuário removido.
- Integrar a entrada de colaboradores ao shell autenticado sem mudar o fluxo individual do MVP.
- Validar que convites não desbloqueiam agentes, canais ou dados fora da permissão concedida.

## Critérios de aceite

## Motion e imersão

As transições devem ser fluidas, suaves e rápidas: comunicar causa, destino e estado sem criar espera artificial. O movimento deve preservar o contexto espacial e respeitar prefers-reduced-motion.

- O primeiro uso funciona sem convite e sem equipe adicional.
- Um convite pode ser enviado, aceito, recusado, expirado e revogado.
- O workspace mostra estado e próxima ação em cada etapa.
- Isolamento, auditoria e permissões continuam válidos.
- Falha de e-mail ou token tem recuperação sem duplicar convite.
- O fluxo passa testes ponta a ponta e acessibilidade.

## Não incluído

Convites durante onboarding inicial, colaboração em tempo real, marketplace de equipe ou expansão automática de permissões.
