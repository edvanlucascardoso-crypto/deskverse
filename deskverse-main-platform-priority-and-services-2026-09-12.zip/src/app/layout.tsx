import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Deskverse — Workspace",
  description: "O espaço de trabalho visual do Deskverse.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
