"use client";

import { AnimatePresence, useReducedMotion } from "motion/react";
import { Bell, Menu, Moon, Search, Sun } from "lucide-react";
import { useCallback, useMemo, useState, type KeyboardEvent } from "react";
import { AgentContextPanel } from "@/components/canvas/agent-context-panel";
import { agents, activities, defaultOrder, isActiveActivity, type AgentActivity, type AgentCommunication, type CanvasState } from "@/components/canvas/agent-data";
import { CanvasMenuSheet } from "@/components/canvas/canvas-menu-sheet";
import { CanvasDndProvider } from "@/components/canvas/canvas-dnd-provider";
import { WorkspaceCanvas, type AgentEntry } from "@/components/canvas/workspace-canvas";
import { moveAgentBefore } from "@/lib/canvas/agent-order";

export default function WorkspacePage() {
  const [canvasState, setCanvasState] = useState<CanvasState>("success");
  const [query, setQuery] = useState("");
  const [view, setView] = useState<"all" | "active" | "available">("all");
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [menuOpen, setMenuOpen] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [focused, setFocused] = useState("social");
  const [order, setOrder] = useState(defaultOrder);
  const [zoom, setZoom] = useState(100);
  const [liveActivity, setLiveActivity] = useState<Record<string, AgentActivity>>({});
  const [communication, setCommunication] = useState<AgentCommunication | null>(null);
  const [notice, setNotice] = useState("Canvas sincronizado agora");
  const reduced = useReducedMotion();

  const currentActivity = useCallback((id: string) => liveActivity[id] ?? agents.find((agent) => agent.id === id)?.activity ?? "idle", [liveActivity]);
  const entries = useMemo<AgentEntry[]>(() => order.map((id) => agents.find((agent) => agent.id === id)).filter((agent): agent is (typeof agents)[number] => Boolean(agent)).map((agent) => ({ agent, activity: currentActivity(agent.id) })).filter(({ agent, activity }) => {
    const matchesQuery = (agent.name + " " + agent.role + " " + agent.detail).toLowerCase().includes(query.toLowerCase());
    const matchesView = view === "all" || (view === "active" ? isActiveActivity(activity) : activity === "idle" || activity === "waiting");
    return matchesQuery && matchesView;
  }), [currentActivity, order, query, view]);
  const selectedAgent = agents.find((agent) => agent.id === selected) ?? null;
  const reorderAgents = useCallback((sourceId: string, targetId: string) => {
    const source = agents.find((agent) => agent.id === sourceId);
    const target = agents.find((agent) => agent.id === targetId);
    if (!source || !target || source.kind !== target.kind) return;
    setOrder((current) => moveAgentBefore(current, sourceId, targetId));
  }, []);
  const commitAgentOrder = useCallback(() => setNotice("Arranjo atualizado"), []);

  const communicate = (fromId: string, toId: string) => {
    if (fromId === toId) return;
    setLiveActivity((current) => ({ ...current, [fromId]: "communicating", [toId]: "communicating" }));
    setCommunication({ fromId, toId });
    setFocused(fromId);
    setSelected(fromId);
    const source = agents.find((agent) => agent.id === fromId)?.name;
    const target = agents.find((agent) => agent.id === toId)?.name;
    setNotice(source + " está em comunicação com " + target);
    window.setTimeout(() => {
      setLiveActivity((current) => ({ ...current, [fromId]: "working", [toId]: "idle" }));
      setCommunication((current) => current?.fromId === fromId && current.toId === toId ? null : current);
    }, 2600);
  };

  const simulateCommunication = () => {
    const source = agents.find((agent) => currentActivity(agent.id) === "working") ?? agents[0];
    communicate(source.id, source.id === "social" ? "copy" : "social");
  };

  const onCanvasKeyDown = (event: KeyboardEvent<HTMLElement>) => {
    const index = entries.findIndex(({ agent }) => agent.id === focused);
    if (event.key === "Escape") {
      setSelected(null);
      setNotice("Seleção limpa");
      return;
    }
    if (!["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp"].includes(event.key)) return;
    event.preventDefault();
    const next = entries[index + (event.key === "ArrowRight" || event.key === "ArrowDown" ? 1 : -1)];
    if (next) {
      setFocused(next.agent.id);
      setSelected(next.agent.id);
    }
  };

  return <main className={"app-shell " + theme}>
    <section className="content" id="canvas">
      <header className="topbar"><div className="brand-cluster"><button className="icon-button menu-button" onClick={() => setMenuOpen(true)} aria-label="Abrir menu" title="Abrir menu"><Menu size={20} /></button><div className="mobile-brand"><span className="brand-mark">D</span><span>deskverse</span></div></div><label className="search"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar agentes" aria-label="Buscar agentes" /></label><div className="top-actions"><button className="icon-button" onClick={() => setMenuOpen(true)} aria-label="Abrir atividade" title="Abrir atividade"><Bell size={19} /><i /></button><button className="theme-button" onClick={() => setTheme((current) => current === "light" ? "dark" : "light")} aria-label="Alternar tema" title="Alternar tema">{theme === "light" ? <Moon size={18} /> : <Sun size={18} />}</button><button className="avatar-button" aria-label="Abrir perfil">VC</button></div></header>
      <div className="workspace-head"><p className="eyebrow">ESPAÇO · ESTÚDIO AURORA</p><h1>Canvas de agentes</h1><p className="subtitle">Líderes coordenam objetivos e compartilham especialistas conforme a tarefa.</p></div>
      <CanvasDndProvider><WorkspaceCanvas canvasState={canvasState} entries={entries} selected={selected} focused={focused} view={view} notice={notice} zoom={zoom} communication={communication} reduced={reduced} onSelect={(id) => { setSelected(id); setFocused(id); }} onReorder={reorderAgents} onOrderCommit={commitAgentOrder} onCanvasKeyDown={onCanvasKeyDown} onZoomChange={setZoom} onSimulateCommunication={simulateCommunication} onRecover={() => { setCanvasState("success"); setNotice("Canvas sincronizado agora"); }} /></CanvasDndProvider>
    </section>
    <AnimatePresence>{selectedAgent && <AgentContextPanel agent={selectedAgent} activity={currentActivity(selectedAgent.id)} reduced={reduced} onClose={() => setSelected(null)} onCommunicate={() => communicate(selectedAgent.id, selectedAgent.id === "social" ? "copy" : "social")} />}</AnimatePresence>
    <CanvasMenuSheet open={menuOpen} setOpen={setMenuOpen} view={view} setView={setView} canvasState={canvasState} setCanvasState={setCanvasState} agents={agents} activities={activities} />
  </main>;
}
