import { motion } from "motion/react";
import { MessageCircle, X } from "lucide-react";
import type { CSSProperties } from "react";
import { activityLabel, isActiveActivity, statusColor, type Agent, type AgentActivity } from "./agent-data";

type AgentContextPanelProps = { agent: Agent; activity: AgentActivity; reduced: boolean | null; onClose: () => void; onCommunicate: () => void };

export function AgentContextPanel({ agent, activity, reduced, onClose, onCommunicate }: AgentContextPanelProps) {
  const Icon = agent.icon;
  const isActive = isActiveActivity(activity);
  const className = "context-logo" + (isActive ? " is-active" : "");
  const statusClassName = "status-pill" + (isActive ? " active" : "");
  const isLeader = agent.kind === "leader";
  return <motion.aside className="context-panel" initial={{ opacity: 0, x: 22 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 22 }} transition={{ duration: reduced ? 0 : 0.2 }} aria-label={"Detalhes de " + agent.name}><button className="close-panel" aria-label="Fechar painel" onClick={onClose}><X size={19} /></button><span className={className} style={{ "--agent-color": agent.color } as CSSProperties}><Icon size={54} strokeWidth={.65} /></span><p className="eyebrow">{isLeader ? "LÍDER" : "ESPECIALISTA"} · {agent.seniority}</p><h2>{agent.name}</h2><motion.span key={activity} className={statusClassName} initial={reduced ? false : { scale: .72, opacity: .35 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: reduced ? 0 : .24, ease: [0.22, 1, 0.36, 1] }} style={{ "--agent-color": agent.color, "--status-color": statusColor(activity) } as CSSProperties} title={activityLabel(activity)} aria-label={activityLabel(activity)}><i /></motion.span><div className="context-block"><h3>Agora</h3><p>{agent.detail}</p></div>{isLeader ? <div className="context-block"><h3>Especialidades</h3><div className="capability-list">{agent.capabilities?.map((item) => <span key={item.capability}>{item.capability}<small>{item.seniority}</small></span>)}</div><p>As delegações são resolvidas por especialidade, sem cópias privadas.</p></div> : <div className="context-block"><h3>Fila da especialidade</h3><p>{agent.queueSummary}</p><p>Este especialista pode atender mais de um líder.</p></div>}<div className="context-block"><button className="primary-button full-width" onClick={onCommunicate}><MessageCircle size={16} /> {isLeader ? "Iniciar comunicação" : "Abrir contexto"}</button></div></motion.aside>;
}
