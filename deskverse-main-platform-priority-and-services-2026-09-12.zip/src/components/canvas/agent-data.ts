import type { LucideIcon } from "lucide-react";
import { Image, LayoutGrid, MessageCircle, Palette, PenLine, Sparkles, Video, WandSparkles } from "lucide-react";

export type CanvasState = "success" | "loading" | "empty" | "error";
export type AgentActivity = "idle" | "working" | "communicating" | "waiting" | "error";
export type AgentCommunication = { fromId: string; toId: string };
export type AgentKind = "leader" | "specialist";
export type Seniority = "Júnior" | "Pleno" | "Sênior" | "Especialista";
export type CapabilityPreference = { capability: string; seniority: Seniority };

export type Agent = {
  id: string;
  name: string;
  role: string;
  taskSummary: string;
  icon: LucideIcon;
  color: string;
  activity: AgentActivity;
  detail: string;
  kind: AgentKind;
  seniority: Seniority;
  capabilities?: CapabilityPreference[];
  queueSummary?: string;
};

export type Activity = { id: string; text: string; time: string; tone: string };

export const agents: Agent[] = [
  { id: "social", name: "Marina Social", role: "Mídias Sociais", taskSummary: "Criando calendário", icon: MessageCircle, color: "#46d3c2", activity: "working", detail: "Preparando o calendário editorial.", kind: "leader", seniority: "Sênior", capabilities: [{ capability: "Pesquisa", seniority: "Júnior" }, { capability: "Redação", seniority: "Sênior" }, { capability: "Design", seniority: "Pleno" }] },
  { id: "manager", name: "Nico Gestor", role: "Operações", taskSummary: "Aguardando resposta", icon: LayoutGrid, color: "#55a8ef", activity: "waiting", detail: "Aguardando uma decisão sua.", kind: "leader", seniority: "Pleno", capabilities: [{ capability: "Pesquisa", seniority: "Pleno" }, { capability: "Revisão", seniority: "Júnior" }, { capability: "Análise", seniority: "Pleno" }] },
  { id: "copy", name: "Alex Redator", role: "Redação", taskSummary: "Livre para pauta", icon: PenLine, color: "#f16bb4", activity: "idle", detail: "Disponível para uma nova pauta.", kind: "specialist", seniority: "Sênior", queueSummary: "1 trabalhando · fila sem espera" },
  { id: "designer", name: "Lia Design", role: "Design", taskSummary: "Aguardando direção", icon: Palette, color: "#f4c64e", activity: "idle", detail: "Aguardando a direção visual.", kind: "specialist", seniority: "Pleno", queueSummary: "2 aguardando · estimativa em breve" },
  { id: "motion", name: "Maya Animação", role: "Animação", taskSummary: "Pronta para animar", icon: WandSparkles, color: "#b683ef", activity: "idle", detail: "Pronta para criar uma animação.", kind: "specialist", seniority: "Pleno", queueSummary: "fila sem espera" },
  { id: "image", name: "Iris Imagem", role: "Criação e edição", taskSummary: "Criando arte", icon: Image, color: "#f28b61", activity: "idle", detail: "Pronta para criar ou editar uma arte.", kind: "specialist", seniority: "Especialista", queueSummary: "1 trabalhando · 1 aguardando" },
  { id: "video", name: "Vini Vídeo", role: "Edição de vídeo", taskSummary: "Precisa de ajuda", icon: Video, color: "#e45d59", activity: "error", detail: "Precisa de ajuda para concluir o render.", kind: "specialist", seniority: "Sênior", queueSummary: "execução pausada para revisão" },
  { id: "research", name: "Rafa Pesquisa", role: "Pesquisa", taskSummary: "Pesquisando tema", icon: Sparkles, color: "#63c77a", activity: "idle", detail: "Disponível para investigar um tema.", kind: "specialist", seniority: "Júnior", queueSummary: "1 trabalhando · fila sem espera" },
];

export const activities: Activity[] = [
  { id: "activity-1", text: "Marina está trabalhando no calendário editorial.", time: "agora", tone: "#46d3c2" },
  { id: "activity-2", text: "Nico aguarda uma decisão sua.", time: "há 4 min", tone: "#f4c64e" },
  { id: "activity-3", text: "Alex está disponível para uma nova pauta.", time: "há 12 min", tone: "#768097" },
];

export const defaultOrder = agents.map((agent) => agent.id);

export function isActiveActivity(activity: AgentActivity) {
  return activity === "working" || activity === "communicating";
}

export function statusColor(activity: AgentActivity) {
  if (activity === "working" || activity === "communicating") return "#a18dff";
  if (activity === "error") return "#f05f68";
  if (activity === "waiting") return "#f4c64e";
  return "#63c77a";
}

export function activityLabel(activity: AgentActivity) {
  if (activity === "communicating") return "Comunicando";
  if (activity === "working") return "Trabalhando";
  if (activity === "error") return "Erro / ajuda";
  if (activity === "waiting") return "Aguardando você";
  return "Disponível";
}
