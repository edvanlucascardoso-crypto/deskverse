export const AGENT_TILE = "agent-tile";

export type AgentTileDragItem = { id: string };
