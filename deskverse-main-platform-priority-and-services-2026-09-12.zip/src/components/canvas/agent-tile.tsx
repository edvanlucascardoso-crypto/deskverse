import { motion } from "motion/react";
import { useDrag, useDrop } from "react-dnd";
import { useEffect, useRef, type CSSProperties } from "react";
import { activityLabel, isActiveActivity, statusColor, type Agent, type AgentActivity } from "./agent-data";
import { AGENT_TILE, type AgentTileDragItem } from "./agent-dnd";

type AgentTileProps = {
  agent: Agent;
  activity: AgentActivity;
  selected: boolean;
  focused: boolean;
  reduced: boolean | null;
  tileRef?: (node: HTMLButtonElement | null) => void;
  onReorder: (sourceId: string, targetId: string) => void;
  onOrderCommit: () => void;
  onSelect: () => void;
};

export function AgentTile({ agent, activity, selected, focused, reduced, tileRef, onReorder, onOrderCommit, onSelect }: AgentTileProps) {
  const Icon = agent.icon;
  const isActive = isActiveActivity(activity);
  const dragRef = useRef<HTMLButtonElement>(null);
  const [{ isDragging }, drag] = useDrag<AgentTileDragItem, void, { isDragging: boolean }>(() => ({ type: AGENT_TILE, item: { id: agent.id }, collect: (monitor) => ({ isDragging: monitor.isDragging() }), end: () => onOrderCommit() }), [agent.id, onOrderCommit]);
  const [, drop] = useDrop<AgentTileDragItem>(() => ({
    accept: AGENT_TILE,
    hover: (item, monitor) => {
      if (item.id === agent.id || !monitor.isOver({ shallow: true })) return;
      const node = dragRef.current;
      const offset = monitor.getClientOffset();
      if (!node || !offset) return;
      const rect = node.getBoundingClientRect();
      const withinX = offset.x > rect.left + rect.width * 0.25 && offset.x < rect.right - rect.width * 0.25;
      const withinY = offset.y > rect.top + rect.height * 0.25 && offset.y < rect.bottom - rect.height * 0.25;
      if (withinX && withinY) onReorder(item.id, agent.id);
    },
    drop: (item) => { if (item.id !== agent.id) onReorder(item.id, agent.id); },
  }), [agent.id, onReorder]);
  useEffect(() => { drag(drop(dragRef)); }, [drag, drop]);
  const setTileRef = (node: HTMLButtonElement | null) => {
    dragRef.current = node;
    tileRef?.(node);
  };
  const className = "agent-tile" + (isActive ? " is-active" : "") + (activity === "communicating" ? " is-communicating" : "") + (selected ? " is-selected" : "") + (focused ? " is-focused" : "") + (isDragging ? " is-dragging" : "");
  return <motion.button ref={setTileRef} data-agent-id={agent.id} layout={!reduced} whileHover={reduced || isDragging ? undefined : { y: -3, scale: 1.015 }} whileTap={reduced || isDragging ? undefined : { scale: .985 }} transition={{ layout: { duration: reduced ? 0 : 0.28, ease: [0.22, 1, 0.36, 1] }, default: { duration: reduced ? 0 : .18, ease: [0.22, 1, 0.36, 1] } }} onClick={onSelect} className={className} style={{ "--agent-color": agent.color, "--status-color": statusColor(activity) } as CSSProperties} aria-pressed={selected}>
    <span className="agent-logo" aria-hidden="true"><Icon size={96} strokeWidth={.30} /></span>
    <span className="agent-copy"><span className="agent-kind">{agent.kind === "leader" ? "Líder" : "Especialista"}</span><span className="agent-name">{agent.name}</span><span className="agent-role">{agent.role} · {agent.seniority}</span></span><motion.span key={activity} className="agent-status" initial={{ scale: .72, opacity: .35 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: reduced ? 0 : .24, ease: [0.22, 1, 0.36, 1] }} title={activityLabel(activity)} aria-label={activityLabel(activity)}><i /></motion.span><span className="agent-task">{activity === "communicating" ? "Em comunicação" : activity === "error" ? "Precisa de ajuda" : activity === "waiting" ? "Aguardando resposta" : agent.taskSummary}</span>
  </motion.button>;
}
