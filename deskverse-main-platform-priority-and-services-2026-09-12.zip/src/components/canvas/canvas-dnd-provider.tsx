"use client";

import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { TouchBackend } from "react-dnd-touch-backend";
import { useSyncExternalStore, type ReactNode } from "react";

const touchQuery = "(pointer: coarse)";

function subscribeToPointerType(onChange: () => void) {
  const media = window.matchMedia(touchQuery);
  media.addEventListener("change", onChange);
  return () => media.removeEventListener("change", onChange);
}

export function CanvasDndProvider({ children }: { children: ReactNode }) {
  const usesTouch = useSyncExternalStore(subscribeToPointerType, () => window.matchMedia(touchQuery).matches, () => false);
  return <DndProvider backend={usesTouch ? TouchBackend : HTML5Backend} options={usesTouch ? { delayTouchStart: 1000 } : undefined}>{children}</DndProvider>;
}
