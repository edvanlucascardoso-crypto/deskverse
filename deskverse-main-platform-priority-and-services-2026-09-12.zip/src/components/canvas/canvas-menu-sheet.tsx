import { Clock3, LayoutGrid, Users } from "lucide-react";
import { Drawer, DrawerContent, DrawerDescription, DrawerHeader, DrawerTitle } from "@/components/ui/drawer";
import type { Activity, Agent, CanvasState } from "./agent-data";

type CanvasMenuSheetProps = {
  open: boolean;
  setOpen: (open: boolean) => void;
  view: "all" | "active" | "available";
  setView: (view: "all" | "active" | "available") => void;
  canvasState: CanvasState;
  setCanvasState: (state: CanvasState) => void;
  agents: Agent[];
  activities: Activity[];
};

export function CanvasMenuSheet({ open, setOpen, view, setView, canvasState, setCanvasState, agents, activities }: CanvasMenuSheetProps) {
  return <Drawer open={open} onOpenChange={setOpen}><DrawerContent className="menu-sheet"><DrawerHeader><DrawerDescription>Deskverse · Estúdio Aurora</DrawerDescription><DrawerTitle>Menu do canvas</DrawerTitle></DrawerHeader><nav className="sheet-nav"><a className="sheet-nav-item active" href="#canvas" onClick={() => setOpen(false)}><LayoutGrid size={18} /> Canvas</a><a className="sheet-nav-item" href="#agents" onClick={() => setOpen(false)}><Users size={18} /> Agentes <span>{agents.length}</span></a><a className="sheet-nav-item" href="#canvas" onClick={() => setOpen(false)}><Clock3 size={18} /> Atividade <span>{activities.length}</span></a></nav><div className="sheet-section"><p className="eyebrow">VISUALIZAÇÃO</p><div className="sheet-tabs"><button className={view === "all" ? "active" : ""} onClick={() => setView("all")}>Todos</button><button className={view === "active" ? "active" : ""} onClick={() => setView("active")}>Em atividade</button><button className={view === "available" ? "active" : ""} onClick={() => setView("available")}>Disponíveis</button></div></div><div className="sheet-section"><p className="eyebrow">ESTADOS DE FIXTURE</p><div className="sheet-tabs"><button className={canvasState === "success" ? "active" : ""} onClick={() => setCanvasState("success")}>Ativo</button><button className={canvasState === "loading" ? "active" : ""} onClick={() => setCanvasState("loading")}>Carregando</button><button className={canvasState === "empty" ? "active" : ""} onClick={() => setCanvasState("empty")}>Vazio</button><button className={canvasState === "error" ? "active" : ""} onClick={() => setCanvasState("error")}>Falha</button></div></div><div className="sheet-section activity-sheet-section"><p className="eyebrow">ATIVIDADE RECENTE</p>{activities.map((activity) => <div className="activity-item" key={activity.id}><i style={{ background: activity.tone }} /><p>{activity.text}<small>{activity.time}</small></p></div>)}</div></DrawerContent></Drawer>;
}
