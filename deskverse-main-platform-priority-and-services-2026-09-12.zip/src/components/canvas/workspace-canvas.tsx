import { AnimatePresence, motion } from "motion/react";
import { Check, CircleAlert, LoaderCircle, Maximize2, Play, RotateCcw, Sparkles, ZoomIn, ZoomOut } from "lucide-react";
import { useRef, type CSSProperties, type KeyboardEvent } from "react";
import { type Agent, type AgentActivity, type AgentCommunication, type CanvasState } from "./agent-data";
import { AgentTile } from "./agent-tile";
import { CommunicationLink } from "./communication-link";
import { Feedback } from "./feedback";

export type AgentEntry = { agent: Agent; activity: AgentActivity };

type WorkspaceCanvasProps = {
  canvasState: CanvasState;
  entries: AgentEntry[];
  selected: string | null;
  focused: string;
  view: "all" | "active" | "available";
  notice: string;
  zoom: number;
  communication: AgentCommunication | null;
  reduced: boolean | null;
  onSelect: (id: string) => void;
  onReorder: (sourceId: string, targetId: string) => void;
  onOrderCommit: () => void;
  onCanvasKeyDown: (event: KeyboardEvent<HTMLElement>) => void;
  onZoomChange: (value: number) => void;
  onSimulateCommunication: () => void;
  onRecover: () => void;
};

export function WorkspaceCanvas({ canvasState, entries, selected, focused, view, notice, zoom, communication, reduced, onSelect, onReorder, onOrderCommit, onCanvasKeyDown, onZoomChange, onSimulateCommunication, onRecover }: WorkspaceCanvasProps) {
  const wallRef = useRef<HTMLDivElement>(null);
  const tileRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const viewLabel = view === "all" ? "Todos os agentes" : view === "active" ? "Agentes em atividade" : "Agentes disponíveis";
  const gridColumns = Math.max(1, Math.ceil(Math.sqrt(entries.length)));
  const mobileGridColumns = Math.min(2, gridColumns);
  const wallMaxWidth = gridColumns * 180 + Math.max(0, gridColumns - 1) * 18;
  const wallStyle = { "--wall-scale": zoom / 100, "--agent-columns": gridColumns, "--agent-mobile-columns": mobileGridColumns, "--agent-wall-max-width": wallMaxWidth + "px" } as CSSProperties;
  const leaders = entries.filter(({ agent }) => agent.kind === "leader");
  const specialists = entries.filter(({ agent }) => agent.kind === "specialist");
  const showSpecialists = zoom >= 90;
  const renderTile = ({ agent, activity }: AgentEntry) => <AgentTile key={agent.id} agent={agent} activity={activity} selected={selected === agent.id} focused={focused === agent.id} reduced={reduced} tileRef={(node) => { tileRefs.current[agent.id] = node; }} onReorder={onReorder} onOrderCommit={onOrderCommit} onSelect={() => onSelect(agent.id)} />;
  return <section className="workspace-canvas" tabIndex={0} onKeyDown={onCanvasKeyDown} aria-label="Canvas em grade de agentes. Use as setas para navegar e Escape para limpar a seleção.">
    <div className="canvas-floating-controls" aria-label="Controles do canvas"><button className="canvas-icon-button" onClick={() => onZoomChange(Math.max(80, zoom - 10))} aria-label="Diminuir zoom" title="Diminuir zoom"><ZoomOut size={17} /></button><button className="canvas-icon-button" onClick={() => onZoomChange(100)} aria-label="Restaurar zoom" title="Restaurar zoom"><Maximize2 size={16} /></button><button className="canvas-icon-button" onClick={() => onZoomChange(Math.min(120, zoom + 10))} aria-label="Aumentar zoom" title="Aumentar zoom"><ZoomIn size={17} /></button></div>
    <button className="canvas-communication-button" onClick={onSimulateCommunication} aria-label="Simular comunicação entre agentes" title="Simular comunicação entre agentes"><Play size={17} /></button>
    <div className="canvas-sync"><span><Check size={14} /> {notice}</span><small>{zoom}%</small></div>
    <AnimatePresence mode="wait">
      {canvasState === "loading" && <Feedback icon={<LoaderCircle className="spin" size={30} />} title="Atualizando o canvas" text="Buscando presença e atividade dos agentes." />}
      {canvasState === "empty" && <Feedback icon={<Sparkles size={30} />} title="O canvas está pronto" text="Quando os agentes começarem a trabalhar, eles aparecerão aqui." action={<button className="primary-button" onClick={onRecover}><RotateCcw size={16} /> Atualizar</button>} />}
      {canvasState === "error" && <Feedback error icon={<CircleAlert size={30} />} title="Não foi possível atualizar" text="Os últimos estados conhecidos continuam seguros." action={<button className="secondary-button" onClick={onRecover}>Tentar novamente</button>} />}
      {canvasState === "success" && <motion.div ref={wallRef} className="agent-wall" id="agents" layout={!reduced} initial={false} animate={{ opacity: 1 }} style={wallStyle}>
        {communication && <CommunicationLink communication={communication} wallRef={wallRef} tileRefs={tileRefs} scale={zoom / 100} reduced={reduced} />}
        <div className="agent-zone"><div className="agent-zone-head"><span>Líderes</span><small>Objetivos e decisões</small></div><div className="agent-zone-grid">{leaders.map(renderTile)}</div></div>
        <div className="agent-zone specialists-zone"><div className="agent-zone-head"><span>Especialistas</span><small>{showSpecialists ? "Compartilhados entre líderes" : specialists.length + " disponíveis"}</small></div>{showSpecialists ? <div className="agent-zone-grid">{specialists.map(renderTile)}</div> : <p className="specialists-collapsed">Aproxime para ver especialidades e níveis.</p>}</div>
        {!entries.length && <p className="grid-empty">Nenhum agente corresponde à busca ou ao filtro.</p>}
      </motion.div>}
    </AnimatePresence>
    <div className="canvas-key-hint"><span><span aria-hidden="true">☷</span> {viewLabel}</span><span>Selecione uma logo para abrir o contexto</span></div>
  </section>;
}
