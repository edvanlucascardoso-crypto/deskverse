"use client";

import * as React from "react";
import { Drawer as DrawerPrimitive } from "vaul";

const Drawer = DrawerPrimitive.Root;
const DrawerTrigger = DrawerPrimitive.Trigger;
const DrawerPortal = DrawerPrimitive.Portal;
const DrawerClose = DrawerPrimitive.Close;

const DrawerOverlay = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Overlay>
>(({ className = "", ...props }, ref) => <DrawerPrimitive.Overlay ref={ref} className={`drawer-overlay ${className}`} {...props} />);
DrawerOverlay.displayName = DrawerPrimitive.Overlay.displayName;

const DrawerContent = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Content>
>(({ className = "", children, ...props }, ref) => <DrawerPortal><DrawerOverlay /><DrawerPrimitive.Content ref={ref} className={`drawer-content ${className}`} {...props}>{children}</DrawerPrimitive.Content></DrawerPortal>);
DrawerContent.displayName = DrawerPrimitive.Content.displayName;

function DrawerHeader({ className = "", ...props }: React.HTMLAttributes<HTMLDivElement>) { return <div className={`drawer-header ${className}`} {...props} />; }
function DrawerTitle({ className = "", ...props }: React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Title>) { return <DrawerPrimitive.Title className={`drawer-title ${className}`} {...props} />; }
function DrawerDescription({ className = "", ...props }: React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Description>) { return <DrawerPrimitive.Description className={`drawer-description ${className}`} {...props} />; }

export { Drawer, DrawerClose, DrawerContent, DrawerDescription, DrawerHeader, DrawerOverlay, DrawerPortal, DrawerTitle, DrawerTrigger };
