export function moveAgentBefore(order: string[], sourceId: string, targetId: string) {
  const sourceIndex = order.indexOf(sourceId);
  const targetIndex = order.indexOf(targetId);
  if (sourceId === targetId || sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex - 1) return order;
  const next = order.filter((id) => id !== sourceId);
  next.splice(next.indexOf(targetId), 0, sourceId);
  return next;
}
